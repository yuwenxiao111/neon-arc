const { app, BrowserWindow, globalShortcut, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const APP_ROOT = path.join(__dirname, '..');
const ENTRY = path.join(APP_ROOT, 'app', 'index.html');

function logLine(msg) {
  try {
    fs.appendFileSync(path.join(APP_ROOT, 'launch.log'), '[' + new Date().toISOString() + '] ' + msg + '\n');
  } catch (e) {}
}

function createWindow() {
  logLine('launch, entry=' + ENTRY + ' exists=' + fs.existsSync(ENTRY));

  const win = new BrowserWindow({
    width: 520,
    height: 924,
    minWidth: 360,
    minHeight: 560,
    backgroundColor: '#050812',
    autoHideMenuBar: true,
    show: false,
    title: '星际弹幕',
    webPreferences: {
      contextIsolation: true,
      backgroundThrottling: false,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.once('ready-to-show', function () { win.show(); });

  win.webContents.on('did-fail-load', function (e, code, desc, url) {
    logLine('did-fail-load ' + code + ' ' + desc + ' ' + url);
  });
  win.webContents.on('did-finish-load', function () {
    logLine('did-finish-load');
  });
  win.webContents.on('render-process-gone', function (e, details) {
    logLine('render-gone ' + JSON.stringify(details));
  });
  win.webContents.on('console-message', function (e, level, msg) {
    logLine('console[' + level + '] ' + msg);
  });

  if (!fs.existsSync(ENTRY)) {
    logLine('ENTRY MISSING, fallback');
  }

  win.loadFile(ENTRY).catch(function (err) { logLine('load-error ' + err.message); });
  win.setAspectRatio(9 / 16);

  globalShortcut.register('F11', function () {
    if (win.isDestroyed()) return;
    win.setFullScreen(!win.isFullScreen());
  });

  win.webContents.setWindowOpenHandler(function (info) {
    shell.openExternal(info.url);
    return { action: 'deny' };
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', function () {
  globalShortcut.unregisterAll();
  app.quit();
});
