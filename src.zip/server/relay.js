const WebSocket = require('ws');

const PORT = parseInt(process.env.PORT || '8899', 10);
const TICK_RATE = 30;
const HISTORY = 12;
const MAX_PLAYERS = 2;

const rooms = new Map();

function newRoom(id) {
  return {
    id: id,
    tick: 0,
    players: new Map(),
    buf: new Map(),
    last: new Map(),
    createdAt: Date.now()
  };
}

function sendAll(room, obj) {
  const text = JSON.stringify(obj);
  room.players.forEach((p, id) => {
    if (p.readyState === WebSocket.OPEN) p.send(text);
  });
}

function trimHistory(room) {
  const floor = room.tick - HISTORY;
  if (room.buf.size > HISTORY + 4) {
    room.buf.forEach((v, k) => {
      if (k < floor) room.buf.delete(k);
    });
  }
}

const wss = new WebSocket.Server({ port: PORT });
console.log('relay listening on ' + PORT);

wss.on('connection', (ws) => {
  ws.room = null;
  ws.slot = -1;
  ws.alive = true;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch (e) { return; }

    if (msg.t === 'join') {
      const roomId = String(msg.room || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6) || 'ROOM1';
      let room = rooms.get(roomId);
      if (!room) {
        room = newRoom(roomId);
        rooms.set(roomId, room);
      }
      if (room.players.size >= MAX_PLAYERS) {
        ws.send(JSON.stringify({ t: 'error', msg: '房间已满（最多 2 人）' }));
        return;
      }
      let slot = 0;
      while (room.players.has(slot)) slot++;
      room.players.set(slot, ws);
      ws.room = room;
      ws.slot = slot;
      ws.seed = msg.seed || Math.floor(Math.random() * 1000000000);
      if (!room.seed) room.seed = ws.seed;
      ws.name = String(msg.name || ('玩家' + (slot + 1))).slice(0, 8);

      ws.send(JSON.stringify({
        t: 'joined',
        room: roomId,
        slot: slot,
        seed: room.seed,
        tick: room.tick,
        players: Array.from(room.players.keys())
      }));
      sendAll(room, {
        t: 'peer',
        count: room.players.size,
        names: Array.from(room.players.entries()).map(([k, v]) => v.name)
      });
      if (!room.started && room.players.size === MAX_PLAYERS) {
        room.started = true;
        room.tick = 0;
        room.buf.clear();
        room.last.clear();
        room.hashCheck = {};
        sendAll(room, { t: 'start', seed: room.seed, tick: 0 });
        console.log('start room ' + room.id);
      }
      console.log('join ' + roomId + ' slot ' + slot + ' players ' + room.players.size);
      return;
    }

    if (msg.t === 'input' && ws.room) {
      const room = ws.room;
      const tick = room.tick;
      let frame = room.buf.get(tick);
      if (!frame) {
        frame = { p: {} };
        room.buf.set(tick, frame);
      }
      frame.p[ws.slot] = {
        dx: Math.max(-14, Math.min(14, Number(msg.dx) || 0)),
        dy: Math.max(-14, Math.min(14, Number(msg.dy) || 0)),
        b: msg.b ? 1 : 0
      };
      room.last.set(ws.slot, { dx: 0, dy: 0, b: 0 });
      trimHistory(room);
      return;
    }

    if (msg.t === 'hash' && ws.room) {
      ws.room.hashCheck = ws.room.hashCheck || {};
      ws.room.hashCheck[ws.slot] = msg.v;
      if (ws.room.players.size > 1) {
        const a = ws.room.hashCheck[0];
        const b = ws.room.hashCheck[1];
        if (a && b && a !== b) {
          sendAll(ws.room, { t: 'desync', a: a, b: b });
          console.log('DESYNC room ' + ws.room.id + ' ' + a + ' vs ' + b);
        }
      }
      return;
    }

    if (msg.t === 'leave' && ws.room) {
      leaveRoom(ws);
    }
  });

  ws.on('close', () => leaveRoom(ws));
  ws.on('error', () => leaveRoom(ws));
});

function leaveRoom(ws) {
  const room = ws.room;
  if (!room) return;
  room.players.delete(ws.slot);
  room.hashCheck && delete room.hashCheck[ws.slot];
  sendAll(room, {
    t: 'peer',
    count: room.players.size,
    names: Array.from(room.players.entries()).map(([k, v]) => v.name)
  });
  ws.room = null;
  if (room.players.size === 0) {
    rooms.delete(room.id);
    console.log('room closed ' + room.id);
  }
}

setInterval(() => {
  rooms.forEach((room) => {
    if (room.players.size === 0) return;
    room.tick++;
    const past = room.tick - 3;
    const frame = room.buf.get(past);
    const inputs = [];
    room.players.forEach((ws, slot) => {
      let v = frame && frame.p[slot];
      if (!v) v = room.last.get(slot) || { dx: 0, dy: 0, b: 0 };
      inputs.push({ slot: slot, dx: v.dx, dy: v.dy, b: v.b });
    });
    sendAll(room, { t: 'tick', n: room.tick, seed: room.seed, inputs: inputs, count: room.players.size });
  });
}, 1000 / TICK_RATE);
