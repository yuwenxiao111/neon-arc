(function () {
  'use strict';

  const VW = 375;
  const VH = 667;
  const STEP = 1 / 60;
  const BEST_KEY = 'neonarc_best_v3';
  const MAX_PARTICLES = 200;

  const cvs = document.getElementById('game');
  const ctx = cvs.getContext('2d', { alpha: false });
  let cw = 0, ch = 0, DPR = 1, scale = 1, ox = 0, oy = 0;

  let rngA = 1;
  function R() {
    rngA = (rngA + 0x6D2B79F5) | 0;
    let t = Math.imul(rngA ^ (rngA >>> 15), 1 | rngA);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function rr(a, b) { return a + R() * (b - a); }
  function ri(a, b) { return a + Math.floor(R() * (b - a + 1)); }

  const MODES = {
    campaign: { name: '战役', desc: '波次推进，每 50 秒 BOSS', enemy: 1, bossEvery: 3000, bossGap: 3000 },
    endless: { name: '无尽', desc: '难度持续爬升，没有终点', enemy: 1.25, bossEvery: 0, bossGap: 0 },
    bossRush: { name: 'BOSS 连战', desc: '只打 BOSS，每场间隔 10 秒', enemy: 0.12, bossEvery: 600, bossGap: 600 },
    coop: { name: '联机合作', desc: '双人同房，中继只转发输入', enemy: 1, bossEvery: 3000, bossGap: 3000 }
  };

  const world = {
    tick: 0, seed: 1, mode: 'campaign',
    players: [], enemies: [], bullets: [], ebullets: [],
    particles: [], rings: [], pickups: [],
    stars: [], score: 0, best: 0,
    boss: null, nextBossAt: 0, nextSpawnAt: 0, wave: 1,
    shakeT: 0, shakeMag: 0, hitFlash: 0,
    over: false, overT: 0, playersDead: 0,
    inputs: []
  };

  let state = 'menu';
  let banner = { text: '', t: 0, life: 0 };
  let net = null;

  const input = {
    keys: Object.create(null),
    poolX: 0, poolY: 0,
    bombAt: 0,
    pointerId: null,
    lastX: 0, lastY: 0
  };

  let audio = null;
  function initAudio() {
    if (audio) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      audio = new AC();
    } catch (e) { audio = null; }
  }
  function sfx(freq, dur, type, vol) {
    if (!audio) return;
    try {
      const o = audio.createOscillator();
      const g = audio.createGain();
      o.type = type || 'square';
      o.frequency.value = freq;
      g.gain.value = vol == null ? 0.05 : vol;
      o.connect(g); g.connect(audio.destination);
      const t = audio.currentTime;
      g.gain.exponentialRampToValueAtTime(0.0006, t + dur);
      o.start(t); o.stop(t + dur);
    } catch (e) {}
  }

  const sprites = new Map();
  function rgba(hex, a) {
    const h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.substring(0, 2), 16) + ',' + parseInt(h.substring(2, 4), 16) + ',' + parseInt(h.substring(4, 6), 16) + ',' + a + ')';
  }
  function glowSprite(color, r) {
    const key = color + '|' + r;
    let c = sprites.get(key);
    if (c) return c;
    c = document.createElement('canvas');
    c.width = r * 2; c.height = r * 2;
    const g = c.getContext('2d');
    const rg = g.createRadialGradient(r, r, 0, r, r, r);
    rg.addColorStop(0, rgba(color, 0.9));
    rg.addColorStop(0.3, rgba(color, 0.4));
    rg.addColorStop(0.64, rgba(color, 0.12));
    rg.addColorStop(1, rgba(color, 0));
    g.fillStyle = rg;
    g.beginPath(); g.arc(r, r, r, 0, Math.PI * 2); g.fill();
    sprites.set(key, c);
    return c;
  }
  function drawGlow(x, y, r, color, alpha) {
    const sp = glowSprite(color, 64);
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.drawImage(sp, x - r * 1.1, y - r * 1.1, r * 2.2, r * 2.2);
    ctx.globalAlpha = 1;
  }

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function resize() {
    const rect = cvs.getBoundingClientRect();
    cw = Math.max(1, Math.round(rect.width));
    ch = Math.max(1, Math.round(rect.height));
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    cvs.width = Math.round(cw * DPR);
    cvs.height = Math.round(ch * DPR);
    scale = Math.min(cw / VW, ch / VH);
    ox = (cw - VW * scale) / 2;
    oy = (ch - VH * scale) / 2;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    buildStars();
  }

  function buildStars() {
    world.stars.length = 0;
    for (let i = 0; i < 130; i++) {
      const layer = i % 3;
      world.stars.push({
        x: Math.random() * VW,
        y: Math.random() * VH,
        s: layer === 0 ? 0.8 : layer === 1 ? 1.2 : 1.8,
        v: layer === 0 ? 0.4 : layer === 1 ? 1.0 : 2.0,
        a: layer === 0 ? 0.22 : layer === 1 ? 0.45 : 0.75,
        c: layer === 2 ? '#ffffff' : '#a9dcff'
      });
    }
  }

  function makePlayer(id, x, y) {
    return {
      id: id, x: x, y: y, r: 15,
      hp: 3, maxHp: 3, inv: 1.4,
      power: 1, kills: 0, fireCd: 0, bombs: 2,
      alive: true, tilt: 0, respawn: 0, color: id === 0 ? '#9df6ff' : '#ffd47b'
    };
  }

  function resetWorld(mode, seed, count) {
    world.tick = 0;
    world.seed = seed || 1;
    rngA = world.seed | 1;
    world.mode = mode || 'campaign';
    world.enemies.length = 0;
    world.bullets.length = 0;
    world.ebullets.length = 0;
    world.particles.length = 0;
    world.rings.length = 0;
    world.pickups.length = 0;
    world.players.length = 0;
    world.score = 0;
    world.boss = null;
    world.wave = 1;
    world.shakeT = 0; world.shakeMag = 0; world.hitFlash = 0;
    world.over = false; world.overT = 0;
    world.playersDead = 0;

    const n = count || 1;
    if (n === 1) {
      world.players.push(makePlayer(0, VW / 2, VH * 0.8));
    } else {
      world.players.push(makePlayer(0, VW / 2 - 42, VH * 0.82));
      world.players.push(makePlayer(1, VW / 2 + 42, VH * 0.82));
    }

    const m = MODES[world.mode] || MODES.campaign;
    world.nextSpawnAt = 40;
    world.nextBossAt = world.mode === 'bossRush' ? 110 : (m.bossEvery || 999999);
    world.inputs = [];
    for (let i = 0; i < world.players.length; i++) world.inputs.push({ dx: 0, dy: 0, b: 0 });
  }

  function showBanner(text, life) {
    banner.text = text;
    banner.t = 0;
    banner.life = life || 1.5;
    const el = document.getElementById('banner');
    el.textContent = text;
    el.classList.remove('hide');
    el.style.animation = 'none';
    void el.offsetWidth;
    el.style.animation = '';
  }

  function boom(x, y, n, color, spd, size) {
    const room = MAX_PARTICLES - world.particles.length;
    const cnt = Math.min(n, Math.max(0, room));
    for (let i = 0; i < cnt; i++) {
      const ang = rr(0, Math.PI * 2);
      const v = rr(0.35, 1) * (spd || 3.2);
      world.particles.push({
        x: x, y: y,
        vx: Math.cos(ang) * v, vy: Math.sin(ang) * v,
        life: rr(0.3, 0.8), t: 0,
        color: color || '#7be9ff',
        size: size || rr(2.5, 6)
      });
    }
  }

  function shock(x, y, r0, r1, color, life) {
    if (world.rings.length > 22) world.rings.shift();
    world.rings.push({ x: x, y: y, r0: r0, r1: r1, t: 0, life: life || 0.45, color: color || '#9df6ff' });
  }

  function shakeSim(m, t) {
    world.shakeMag = Math.max(world.shakeMag, m);
    world.shakeT = Math.max(world.shakeT, t);
  }

  function spawnEnemy(power) {
    const kinds = ['drone', 'drone', 'drone', 'wisp'];
    const tsec = world.tick / 60;
    if (tsec > 14) kinds.push('turret');
    if (tsec > 26) kinds.push('tank', 'wisp', 'turret');
    const kind = kinds[ri(0, kinds.length - 1)];
    const x = rr(46, VW - 46);
    const diff = 1 + tsec / 65;
    const e = { x: x, x0: x, y: -46, t: 0, fire: rr(1, 2), kind: kind, hit: 0, flash: 0, phase: rr(0, 6.28) };
    if (kind === 'drone') {
      e.r = 15; e.hp = e.maxHp = Math.round((3 + diff * 1.2) * (power || 1));
      e.vy = 46 + diff * 10; e.vx = rr(-22, 22); e.pts = 70; e.color = '#ff5d7a';
    } else if (kind === 'wisp') {
      e.r = 16; e.hp = e.maxHp = Math.round((4 + diff * 1.4) * (power || 1));
      e.vy = 34 + diff * 6; e.amp = rr(38, 76); e.freq = rr(1.2, 2.2); e.pts = 110; e.color = '#ff9ad5';
    } else if (kind === 'turret') {
      e.r = 19; e.hp = e.maxHp = Math.round((8 + diff * 2) * (power || 1));
      e.vy = 26 + diff * 4; e.pts = 180; e.color = '#ff8a5c';
    } else {
      e.r = 27; e.hp = e.maxHp = Math.round((16 + diff * 3.4) * (power || 1));
      e.vy = 18 + diff * 2.4; e.pts = 320; e.color = '#c6a8ff';
    }
    world.enemies.push(e);
  }

  function spawnBoss() {
    const tier = Math.floor(world.tick / (MODES[world.mode].bossGap || 3000));
    const hpBase = 150 + tier * 110;
    const np = world.players.length;
    world.boss = {
      x: VW / 2, y: -120, r: 52,
      hp: Math.round(hpBase * (1 + (np - 1) * 0.75)), maxHp: Math.round(hpBase * (1 + (np - 1) * 0.75)),
      t: 0, fire: 0, ring: 4, hit: 0, tier: tier, flash: 0, phase: rr(0, 6.28)
    };
    document.getElementById('bossBarWrap').classList.remove('hide');
    document.getElementById('bossBar').style.width = '100%';
    showBanner('BOSS 来袭', 2);
    sfx(120, 0.8, 'sawtooth', 0.08);
  }

  function playerFire(p) {
    const y0 = p.y - p.r - 8;
    const spd = -690;
    if (p.power === 1) {
      world.bullets.push({ x: p.x, y: y0, vx: 0, vy: spd, dmg: 2, w: 4, c: p.color, pid: p.id });
    } else if (p.power === 2) {
      world.bullets.push({ x: p.x - 9, y: y0, vx: 0, vy: spd, dmg: 2, w: 4, c: p.color, pid: p.id });
      world.bullets.push({ x: p.x + 9, y: y0, vx: 0, vy: spd, dmg: 2, w: 4, c: p.color, pid: p.id });
    } else if (p.power === 3) {
      world.bullets.push({ x: p.x, y: y0, vx: 0, vy: spd * 1.05, dmg: 4, w: 6, c: '#c6a8ff', pid: p.id });
      world.bullets.push({ x: p.x - 11, y: y0 + 8, vx: -95, vy: spd * 0.94, dmg: 2, w: 4, c: p.color, pid: p.id });
      world.bullets.push({ x: p.x + 11, y: y0 + 8, vx: 95, vy: spd * 0.94, dmg: 2, w: 4, c: p.color, pid: p.id });
    } else if (p.power === 4) {
      world.bullets.push({ x: p.x, y: y0, vx: 0, vy: spd * 1.08, dmg: 4, w: 7, c: '#ffd47b', pid: p.id });
      world.bullets.push({ x: p.x - 12, y: y0 + 5, vx: -72, vy: spd * 0.96, dmg: 2, w: 4, c: p.color, pid: p.id });
      world.bullets.push({ x: p.x + 12, y: y0 + 5, vx: 72, vy: spd * 0.96, dmg: 2, w: 4, c: p.color, pid: p.id });
      world.bullets.push({ x: p.x - 21, y: y0 + 12, vx: -158, vy: spd * 0.9, dmg: 2, w: 4, c: '#ff9ad5', pid: p.id });
      world.bullets.push({ x: p.x + 21, y: y0 + 12, vx: 158, vy: spd * 0.9, dmg: 2, w: 4, c: '#ff9ad5', pid: p.id });
    } else {
      for (let i = -2; i <= 2; i++) {
        world.bullets.push({ x: p.x + i * 10, y: y0, vx: i * 58, vy: spd, dmg: 3, w: 5, c: '#ffffff', pid: p.id });
      }
      world.bullets.push({ x: p.x, y: y0 - 6, vx: 0, vy: spd * 1.15, dmg: 8, w: 11, c: '#ffd47b', pid: p.id });
    }
  }

  function useBomb(p) {
    if (!p.alive || p.bombs <= 0) return;
    p.bombs--;
    world.hitFlash = 0.45;
    shakeSim(10, 0.5);
    shock(p.x, p.y, 20, 460, '#ffffff', 0.55);
    world.ebullets.length = 0;
    for (let i = world.enemies.length - 1; i >= 0; i--) {
      const e = world.enemies[i];
      boom(e.x, e.y, 9, e.color, 4.5);
      world.score += e.pts;
      world.enemies.splice(i, 1);
    }
    if (world.boss) { world.boss.hp -= 80; world.boss.hit = 0.35; world.boss.flash = 0.2; }
    boom(p.x, p.y, 26, '#ffe9b8', 7);
    sfx(90, 0.6, 'sawtooth', 0.09);
  }

  function damagePlayer(p) {
    if (p.inv > 0 || !p.alive) return;
    p.hp--;
    p.inv = 1.6;
    world.hitFlash = 0.32;
    shakeSim(8, 0.35);
    boom(p.x, p.y, 12, '#ff5d7a', 4.5);
    shock(p.x, p.y, 8, 70, '#ff5d7a', 0.35);
    sfx(300, 0.28, 'square', 0.07);
    if (p.hp <= 0) {
      p.alive = false;
      boom(p.x, p.y, 36, '#ff5d7a', 6);
      shock(p.x, p.y, 10, 160, '#ff9ad5', 0.6);
      if (world.players.length > 1) {
        p.respawn = 8 * 60;
        showBanner('P' + (p.id + 1) + ' 阵亡 · 8 秒后归队', 1.6);
      } else {
        world.over = true;
        world.overT = 40;
      }
    }
  }

  function addKill(p, pts) {
    p.kills++;
    world.score += pts;
    const need = p.power === 1 ? 5 : p.power === 2 ? 9 : p.power === 3 ? 14 : 20;
    if (p.power < 5 && p.kills >= need) {
      p.power++;
      p.kills = 0;
      showBanner('P' + (p.id + 1) + ' 火力升级 · ' + ['单发脉冲', '双列脉冲', '三向散射', '五向散射', '五向强化'][p.power - 1], 1.4);
      shock(p.x, p.y, 10, 90, '#ffd47b', 0.5);
      sfx(760, 0.22, 'triangle', 0.07);
    }
  }

  function stepOne() {
    if (world.over) {
      if (world.overT > 0) {
        world.overT--;
        if (world.overT === 0) gameOver();
      }
      return;
    }
    world.tick++;

    if (world.shakeT > 0) { world.shakeT -= STEP; if (world.shakeT <= 0) world.shakeMag = 0; }
    if (world.hitFlash > 0) world.hitFlash -= STEP;

    const m = MODES[world.mode] || MODES.campaign;
    const tsec = world.tick / 60;

    for (let pi = 0; pi < world.players.length; pi++) {
      const p = world.players[pi];
      const inp = world.inputs[pi] || { dx: 0, dy: 0, b: 0 };
      if (!p.alive) {
        if (world.players.length > 1) {
          p.respawn--;
          if (p.respawn <= 0) {
            p.alive = true;
            p.hp = 1;
            p.inv = 2;
            p.x = VW / 2 + (p.id === 0 ? -42 : 42);
            p.y = VH * 0.82;
          }
        }
        continue;
      }
      if (p.inv > 0) p.inv -= STEP;

      p.x += inp.dx;
      p.y += inp.dy;
      p.tilt = clamp(inp.dx * 0.3, -0.5, 0.5);
      p.x = clamp(p.x, p.r + 6, VW - p.r - 6);
      p.y = clamp(p.y, VH * 0.22, VH - p.r - 10);

      if (inp.b) useBomb(p);

      p.fireCd -= STEP;
      if (p.fireCd <= 0) {
        playerFire(p);
        p.fireCd = p.power >= 4 ? 0.11 : 0.16;
        sfx(940, 0.04, 'square', 0.015);
      }
    }

    for (let i = world.bullets.length - 1; i >= 0; i--) {
      const b = world.bullets[i];
      b.x += b.vx * STEP; b.y += b.vy * STEP;
      if (b.y < -24 || b.x < -24 || b.x > VW + 24) { world.bullets.splice(i, 1); continue; }
      for (let j = world.enemies.length - 1; j >= 0; j--) {
        const e = world.enemies[j];
        if (Math.hypot(e.x - b.x, e.y - b.y) < e.r + b.w * 0.6) {
          e.hp -= b.dmg; e.hit = 0.14; e.flash = 0.1;
          boom(b.x, b.y, 2, b.c, 2, 2.6);
          world.bullets.splice(i, 1);
          if (e.hp <= 0) {
            boom(e.x, e.y, e.kind === 'tank' ? 20 : e.kind === 'turret' ? 14 : 10, e.color, 4);
            shock(e.x, e.y, 3, e.r * 2.6, e.color, 0.32);
            const owner = world.players[b.pid] || world.players[0];
            addKill(owner, e.pts);
            sfx(230, 0.14, 'square', 0.045);
            world.enemies.splice(j, 1);
          }
          break;
        }
      }
      if (world.boss && world.bullets[i]) {
        const bl = world.bullets[i];
        if (Math.hypot(world.boss.x - bl.x, world.boss.y - bl.y) < world.boss.r * 0.92) {
          world.boss.hp -= bl.dmg; world.boss.hit = 0.12; world.boss.flash = 0.08;
          boom(bl.x, bl.y, 2, '#ffd47b', 2, 2.6);
          world.bullets.splice(i, 1);
        }
      }
    }

    for (let i = world.ebullets.length - 1; i >= 0; i--) {
      const b = world.ebullets[i];
      b.x += b.vx * STEP; b.y += b.vy * STEP; b.t += STEP;
      if (b.y > VH + 24 || b.y < -24 || b.x < -24 || b.x > VW + 24) { world.ebullets.splice(i, 1); continue; }
      for (let pi = 0; pi < world.players.length; pi++) {
        const p = world.players[pi];
        if (p.alive && Math.hypot(p.x - b.x, p.y - b.y) < p.r + b.r - 3) {
          world.ebullets.splice(i, 1);
          damagePlayer(p);
          break;
        }
      }
    }

    for (let i = world.enemies.length - 1; i >= 0; i--) {
      const e = world.enemies[i];
      e.t += STEP;
      if (e.hit > 0) e.hit -= STEP;
      if (e.flash > 0) e.flash -= STEP;
      if (e.kind === 'wisp') {
        e.y += e.vy * STEP;
        e.x = e.x0 + Math.sin(e.t * e.freq) * e.amp;
      } else {
        e.y += e.vy * STEP;
        e.x += (e.vx || 0) * STEP;
      }
      if (e.x < e.r) { e.x = e.r; e.vx = Math.abs(e.vx || 0); }
      if (e.x > VW - e.r) { e.x = VW - e.r; e.vx = -Math.abs(e.vx || 0); }

      const nearest = nearestPlayer(e.x, e.y);
      if (e.kind === 'turret' && e.y > 24 && e.y < VH - 40 && nearest) {
        e.fire -= STEP;
        if (e.fire <= 0) {
          e.fire = Math.max(1.3, 2.3 - tsec / 90);
          const ang = Math.atan2(nearest.y - e.y, nearest.x - e.x);
          for (let n = -1; n <= 1; n++) {
            const a = ang + n * 0.24;
            world.ebullets.push({ x: e.x, y: e.y + e.r * 0.6, vx: Math.cos(a) * 165, vy: Math.sin(a) * 165, r: 6, t: 0, c: '#ff9a5c' });
          }
          sfx(420, 0.1, 'triangle', 0.035);
        }
      }
      if (e.kind === 'wisp' && e.y > 20 && e.y < VH - 60) {
        e.fire -= STEP;
        if (e.fire <= 0) {
          e.fire = 2.4;
          world.ebullets.push({ x: e.x, y: e.y + 10, vx: 0, vy: 190, r: 5, t: 0, c: '#ff9ad5' });
        }
      }
      if (e.kind === 'tank' && e.y > 10) {
        e.fire -= STEP;
        if (e.fire <= 0) {
          e.fire = 2.8;
          for (let n = 0; n < 10; n++) {
            const a = (Math.PI * 2 / 10) * n + e.t * 0.25;
            world.ebullets.push({ x: e.x, y: e.y, vx: Math.cos(a) * 128, vy: Math.sin(a) * 128, r: 6, t: 0, c: '#c6a8ff' });
          }
          sfx(300, 0.14, 'triangle', 0.04);
        }
      }

      if (e.y > VH + e.r) { world.enemies.splice(i, 1); continue; }

      for (let pi = 0; pi < world.players.length; pi++) {
        const p = world.players[pi];
        if (p.alive && Math.hypot(p.x - e.x, p.y - e.y) < p.r + e.r * 0.8) {
          boom(e.x, e.y, 10, e.color, 4);
          world.enemies.splice(i, 1);
          damagePlayer(p);
          break;
        }
      }
    }

    if (world.boss) {
      const b = world.boss;
      b.t += STEP;
      if (b.hit > 0) b.hit -= STEP;
      if (b.flash > 0) b.flash -= STEP;
      if (b.y < 168) b.y += 62 * STEP;
      else b.x = VW / 2 + Math.sin(b.t * 0.7 + b.phase) * 96;
      b.fire -= STEP;
      b.ring -= STEP;
      const target = nearestPlayer(b.x, b.y);
      if (b.fire <= 0) {
        b.fire = Math.max(0.62, 1.15 - b.tier * 0.14);
        const ang = target ? Math.atan2(target.y - b.y, target.x - b.x) : Math.PI / 2;
        for (let n = -2; n <= 2; n++) {
          const a = ang + n * 0.2;
          world.ebullets.push({ x: b.x, y: b.y + 22, vx: Math.cos(a) * 200, vy: Math.sin(a) * 200, r: 7, t: 0, c: '#ff5d7a' });
        }
      }
      if (b.ring <= 0) {
        b.ring = 3.6;
        const cnt = 16 + b.tier * 2;
        for (let n = 0; n < cnt; n++) {
          const a = (Math.PI * 2 / cnt) * n + b.t * 0.3;
          world.ebullets.push({ x: b.x, y: b.y, vx: Math.cos(a) * 116, vy: Math.sin(a) * 116, r: 6, t: 0, c: '#ffd47b' });
        }
        shock(b.x, b.y, b.r, b.r + 40, '#ffd47b', 0.4);
        sfx(200, 0.22, 'sawtooth', 0.045);
      }
      for (let pi = 0; pi < world.players.length; pi++) {
        const p = world.players[pi];
        if (p.alive && Math.hypot(p.x - b.x, p.y - b.y) < p.r + b.r * 0.9) damagePlayer(p);
      }
      document.getElementById('bossBar').style.width = Math.max(0, (b.hp / b.maxHp) * 100) + '%';
      if (b.hp <= 0) {
        boom(b.x, b.y, 40, '#ffd47b', 8);
        shock(b.x, b.y, 20, 220, '#ffffff', 0.7);
        world.score += 1200 + b.tier * 400;
        world.boss = null;
        document.getElementById('bossBarWrap').classList.add('hide');
        world.nextBossAt = world.tick + (MODES[world.mode].bossGap || 3000);
        shakeSim(13, 0.6);
        world.players.forEach((p) => { p.bombs = Math.min(4, p.bombs + 1); });
        showBanner('BOSS 击破', 1.6);
        sfx(150, 0.5, 'sawtooth', 0.09);
      }
    }

    for (let i = world.pickups.length - 1; i >= 0; i--) {
      const pk = world.pickups[i];
      pk.t += STEP;
      pk.y += pk.vy * STEP;
      if (pk.y > VH + 24) { world.pickups.splice(i, 1); continue; }
      for (let pi = 0; pi < world.players.length; pi++) {
        const p = world.players[pi];
        if (p.alive && Math.hypot(p.x - pk.x, p.y - pk.y) < p.r + 14) {
          world.pickups.splice(i, 1);
          shock(pk.x, pk.y, 4, 46, '#ffd47b', 0.3);
          p.bombs = Math.min(4, p.bombs + 1);
          sfx(780, 0.14, 'triangle', 0.06);
          break;
        }
      }
    }

    for (let i = world.particles.length - 1; i >= 0; i--) {
      const p = world.particles[i];
      p.t += STEP;
      p.x += p.vx * STEP; p.y += p.vy * STEP;
      p.vx *= 0.93; p.vy *= 0.93;
      if (p.t >= p.life) world.particles.splice(i, 1);
    }
    for (let i = world.rings.length - 1; i >= 0; i--) {
      const r = world.rings[i];
      r.t += STEP;
      if (r.t >= r.life) world.rings.splice(i, 1);
    }

    if (!world.boss) {
      if (world.tick > world.nextSpawnAt) {
        world.nextSpawnAt = world.tick + Math.round(Math.max(18, 54 - tsec / 1.6) * (m.enemy && m.enemy < 1 ? 1 / m.enemy : 1));
        if (m.enemy > 0.5) spawnEnemy(1);
        if (tsec > 20 && R() < 0.3 && m.enemy > 0.5) spawnEnemy(1);
        if (tsec > 40 && R() < 0.2 && m.enemy > 0.5) spawnEnemy(1.2);
      }
      if (m.bossEvery && world.tick > world.nextBossAt && !world.boss) spawnBoss();
    }

    const w = Math.floor(tsec / 30) + 1;
    if (w > world.wave) {
      world.wave = w;
      showBanner('WAVE ' + world.wave, 1.4);
      sfx(580, 0.18, 'triangle', 0.06);
    }
  }

  function nearestPlayer(x, y) {
    let best = null;
    let bd = 1e9;
    for (let i = 0; i < world.players.length; i++) {
      const p = world.players[i];
      if (!p.alive) continue;
      const d = Math.hypot(p.x - x, p.y - y);
      if (d < bd) { bd = d; best = p; }
    }
    return best;
  }

  function hashWorld() {
    let h = 2166136261;
    const acc = (v) => { h ^= (v | 0); h = Math.imul(h, 16777619); };
    acc(world.tick);
    acc(world.score);
    for (let i = 0; i < world.players.length; i++) {
      const p = world.players[i];
      acc(Math.round(p.x * 100));
      acc(Math.round(p.y * 100));
      acc(p.hp); acc(p.power); acc(p.alive ? 1 : 0);
    }
    acc(world.enemies.length);
    acc(world.bullets.length);
    acc(world.ebullets.length);
    acc(world.boss ? Math.round(world.boss.hp) : 0);
    return (h >>> 0).toString(16);
  }

  const netState = { ws: null, room: '', slot: 0, connected: false, pending: null, queue: [], names: [] };

  function connectNet(addr, room, name, seed) {
    if (netState.ws) { try { netState.ws.close(); } catch (e) {} }
    let ws;
    try { ws = new WebSocket(addr); } catch (e) { return false; }
    netState.ws = ws;
    netState.room = room;
    netState.connected = false;
    netState.names = [];
    setNetStatus('连接 ' + addr + ' …');

    ws.onopen = () => {
      ws.send(JSON.stringify({ t: 'join', room: room, name: name, seed: seed }));
    };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (msg.t === 'joined') {
        netState.connected = true;
        netState.slot = msg.slot;
        setNetStatus('已进入房间 ' + msg.room + '（你是 P' + (msg.slot + 1) + '），等另一名玩家…');
      } else if (msg.t === 'start') {
        netState.queue = [];
        startPlay('coop', msg.seed, 2);
      } else if (msg.t === 'tick') {
        const inputs = [];
        for (let i = 0; i < 2; i++) {
          const f = msg.inputs.find((x) => x.slot === i) || { dx: 0, dy: 0, b: 0 };
          inputs.push({ dx: f.dx, dy: f.dy, b: f.b });
        }
        netState.queue.push({ n: msg.n, inputs: inputs });
        if (netState.queue.length > 14) netState.queue.splice(0, netState.queue.length - 14);
        setNetStatus('房间 ' + netState.room + ' · ' + msg.count + ' 人在线');
      } else if (msg.t === 'peer') {
        netState.names = msg.names || [];
      } else if (msg.t === 'error') {
        setNetStatus(msg.msg);
      } else if (msg.t === 'desync') {
        setNetStatus('检测到不同步，已重新同步');
      }
    };
    ws.onclose = () => {
      netState.connected = false;
      setNetStatus('连接已断开');
    };
    ws.onerror = () => { setNetStatus('连接失败，检查地址和端口'); };
    return true;
  }

  function setNetStatus(text) {
    const el = document.getElementById('netStatus');
    if (el) el.textContent = text;
  }

  function sampleInput() {
    let dx = input.poolX;
    let dy = input.poolY;
    input.poolX = 0;
    input.poolY = 0;

    const k = input.keys;
    let ax = 0, ay = 0;
    if (k['a'] || k['arrowleft']) ax -= 1;
    if (k['d'] || k['arrowright']) ax += 1;
    if (k['w'] || k['arrowup']) ay -= 1;
    if (k['s'] || k['arrowdown']) ay += 1;
    if (ax || ay) {
      const len = Math.hypot(ax, ay) || 1;
      dx += (ax / len) * 4.6;
      dy += (ay / len) * 4.6;
    }
    dx = clamp(dx, -14, 14);
    dy = clamp(dy, -14, 14);
    const b = input.bombAt > 0 ? 1 : 0;
    input.bombAt = 0;
    return { dx: dx, dy: dy, b: b };
  }

  function gameOver() {
    state = 'over';
    const best = world.score > world.best ? world.score : world.best;
    world.best = best;
    try { localStorage.setItem(BEST_KEY, String(best)); } catch (e) {}
    document.getElementById('over').classList.remove('hide');
    document.getElementById('btnPause').classList.add('hide');
    document.getElementById('btnBomb').classList.add('hide');
    document.getElementById('banner').classList.add('hide');
    document.getElementById('finalScore').textContent = String(world.score);
    document.getElementById('bestScore').textContent = String(best);
    document.getElementById('waveEnd').textContent = String(world.wave);
    sfx(180, 0.55, 'sawtooth', 0.07);
  }

  function startPlay(mode, seed, count) {
    initAudio();
    if (audio && audio.state === 'suspended') audio.resume();
    resize();
    resetWorld(mode, seed || (Date.now() % 1000000), count || 1);
    state = 'play';
    document.getElementById('menu').classList.add('hide');
    document.getElementById('netPanel').classList.add('hide');
    document.getElementById('over').classList.add('hide');
    document.getElementById('pauseLayer').classList.add('hide');
    document.getElementById('hud').classList.remove('hide');
    document.getElementById('hudVeil').classList.remove('hide');
    document.getElementById('btnPause').classList.remove('hide');
    document.getElementById('btnBomb').classList.remove('hide');
    document.getElementById('bossBarWrap').classList.add('hide');
    const p2 = document.getElementById('heartsP2');
    if (p2) p2.style.display = world.players.length > 1 ? 'block' : 'none';
    showBanner(MODES[mode].name + ' 开始', 1.4);
    sfx(520, 0.14, 'triangle', 0.07);
  }

  function togglePause() {
    if (state === 'play') {
      state = 'pause';
      document.getElementById('pauseLayer').classList.remove('hide');
    } else if (state === 'pause') {
      state = 'play';
      document.getElementById('pauseLayer').classList.add('hide');
    }
  }

  function hidePanels() {
    ['over', 'pauseLayer', 'netPanel', 'hud', 'hudVeil', 'banner', 'bossBarWrap'].forEach(function (id) {
      const el = document.getElementById(id);
      if (el) el.classList.add('hide');
    });
    ['btnPause', 'btnBomb'].forEach(function (id) {
      const el = document.getElementById(id);
      if (el) el.classList.add('hide');
    });
  }

  function backToMenu() {
    state = 'menu';
    hidePanels();
    const menu = document.getElementById('menu');
    menu.classList.remove('hide');
    document.getElementById('bestInMenu').textContent = String(world.best);
    if (netState.ws) {
      try { netState.ws.send(JSON.stringify({ t: 'leave' })); } catch (e) {}
      try { netState.ws.close(); } catch (e) {}
      netState.ws = null;
    }
    netState.connected = false;
    netState.queue = [];
    banner.life = 0;
  }

  function drawPlayerShape(p, alpha) {
    const r = p.r;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    drawGlow(p.x, p.y + r * 0.6, r * 1.9, p.color, 0.45 * alpha);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = alpha;
    ctx.translate(p.x, p.y);
    ctx.rotate(p.tilt);

    const flame = 0.7 + Math.sin(world.tick * 0.6) * 0.3;
    const fg = ctx.createLinearGradient(0, r * 0.4, 0, r * 2.1 * flame);
    fg.addColorStop(0, 'rgba(190,245,255,0.95)');
    fg.addColorStop(0.5, 'rgba(90,200,255,0.5)');
    fg.addColorStop(1, 'rgba(60,140,255,0)');
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.moveTo(-r * 0.34, r * 0.55);
    ctx.lineTo(0, r * (1.1 + flame));
    ctx.lineTo(r * 0.34, r * 0.55);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#1a4a72';
    ctx.beginPath();
    ctx.moveTo(-r * 0.92, r * 0.68); ctx.lineTo(-r * 0.62, -r * 0.1); ctx.lineTo(0, r * 0.5);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.92, r * 0.68); ctx.lineTo(r * 0.62, -r * 0.1); ctx.lineTo(0, r * 0.5);
    ctx.closePath(); ctx.fill();

    const bg = ctx.createLinearGradient(0, -r * 1.3, 0, r * 0.85);
    bg.addColorStop(0, p.color === '#ffd47b' ? '#fff6d9' : '#c9fbff');
    bg.addColorStop(0.55, p.color);
    bg.addColorStop(1, '#2a86c8');
    ctx.fillStyle = bg;
    ctx.beginPath();
    ctx.moveTo(0, -r * 1.32);
    ctx.lineTo(r * 0.8, r * 0.72);
    ctx.lineTo(0, r * 0.3);
    ctx.lineTo(-r * 0.8, r * 0.72);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(210,250,255,0.85)';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.beginPath();
    ctx.ellipse(0, -r * 0.2, r * 0.22, r * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    if (p.power >= 3) {
      ctx.strokeStyle = 'rgba(255,215,120,0.5)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, r * 1.55 + Math.sin(world.tick * 0.3) * 2, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
    ctx.globalAlpha = 1;
  }

  function drawEnemyShape(e) {
    const flash = e.flash > 0;
    ctx.save();
    const fade = e.y < 42 ? Math.max(0, (e.y + 48) / 90) : 1;
    ctx.globalAlpha = fade;
    ctx.globalCompositeOperation = 'lighter';
    drawGlow(e.x, e.y, e.r * 1.55, e.color, 0.32);
    ctx.globalCompositeOperation = 'source-over';
    ctx.translate(e.x, e.y);
    const body = flash ? '#ffffff' : rgba(e.color, 0.88);
    const edge = flash ? '#ffffff' : rgba(e.color, 1);

    if (e.kind === 'drone') {
      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.moveTo(0, e.r); ctx.lineTo(e.r * 0.95, -e.r * 0.55); ctx.lineTo(0, -e.r * 0.15);
      ctx.lineTo(-e.r * 0.95, -e.r * 0.55); ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = edge; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.fillStyle = flash ? '#ffffff' : '#fff0f3';
      ctx.beginPath(); ctx.arc(0, -e.r * 0.1, e.r * 0.26, 0, Math.PI * 2); ctx.fill();
    } else if (e.kind === 'wisp') {
      ctx.rotate(e.t * 1.4);
      ctx.fillStyle = body;
      for (let s = 0; s < 4; s++) {
        ctx.rotate(Math.PI / 2);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(e.r * 0.4, -e.r * 0.5, e.r * 0.98, 0);
        ctx.quadraticCurveTo(e.r * 0.4, e.r * 0.5, 0, 0);
        ctx.fill();
      }
      ctx.fillStyle = '#fff0fb';
      ctx.beginPath(); ctx.arc(0, 0, e.r * 0.24, 0, Math.PI * 2); ctx.fill();
    } else if (e.kind === 'turret') {
      ctx.fillStyle = body;
      ctx.beginPath();
      for (let s = 0; s < 6; s++) {
        const a = Math.PI / 3 * s + Math.PI / 6;
        const px = Math.cos(a) * e.r, py = Math.sin(a) * e.r;
        if (s === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = edge; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.fillStyle = '#1a0d12';
      ctx.beginPath(); ctx.arc(0, 0, e.r * 0.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = flash ? '#ffffff' : '#ffd0a8';
      ctx.beginPath(); ctx.arc(0, 0, e.r * 0.24, 0, Math.PI * 2); ctx.fill();
      const tp = nearestPlayer(e.x, e.y);
      const ang = tp ? Math.atan2(tp.y - e.y, tp.x - e.x) : Math.PI / 2;
      ctx.rotate(ang);
      ctx.fillStyle = '#2a1418';
      ctx.fillRect(e.r * 0.3, -e.r * 0.16, e.r * 0.6, e.r * 0.32);
    } else {
      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.moveTo(-e.r, -e.r * 0.32);
      ctx.lineTo(-e.r * 0.55, -e.r * 0.95);
      ctx.lineTo(e.r * 0.55, -e.r * 0.95);
      ctx.lineTo(e.r, -e.r * 0.32);
      ctx.lineTo(e.r * 0.62, e.r * 0.9);
      ctx.lineTo(-e.r * 0.62, e.r * 0.9);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = edge; ctx.lineWidth = 1.8; ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.45)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-e.r * 0.72, -e.r * 0.2);
      ctx.lineTo(e.r * 0.72, -e.r * 0.2);
      ctx.stroke();
      ctx.fillStyle = flash ? '#ffffff' : '#f3e6ff';
      ctx.beginPath(); ctx.arc(0, e.r * 0.18, e.r * 0.22, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();

    if (e.maxHp > 6) {
      const hpr = Math.max(0, e.hp / e.maxHp);
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(e.x - e.r, e.y - e.r - 11, e.r * 2, 3);
      ctx.fillStyle = hpr > 0.5 ? '#7bffb2' : hpr > 0.25 ? '#ffd47b' : '#ff5d7a';
      ctx.fillRect(e.x - e.r, e.y - e.r - 11, e.r * 2 * hpr, 3);
    }
  }

  function drawBossShape(b) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    drawGlow(b.x, b.y, b.r * 1.5, b.flash > 0 ? '#ffffff' : '#ff335f', 0.38);
    ctx.globalCompositeOperation = 'source-over';
    ctx.translate(b.x, b.y);

    ctx.save();
    ctx.rotate(b.t * 0.55);
    for (let s = 0; s < 8; s++) {
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = b.flash > 0 ? '#ffffff' : 'rgba(255,110,145,0.85)';
      ctx.beginPath();
      ctx.moveTo(b.r * 0.96, -b.r * 0.15);
      ctx.lineTo(b.r * 1.28, -b.r * 0.05);
      ctx.lineTo(b.r * 1.28, b.r * 0.05);
      ctx.lineTo(b.r * 0.96, b.r * 0.15);
      ctx.closePath();
      ctx.fill();
    }
    ctx.strokeStyle = 'rgba(255,140,170,0.45)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(0, 0, b.r * 1.12, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    const oct = function (sx, sy) {
      ctx.beginPath();
      ctx.moveTo(0, -b.r * 0.95 * sy);
      ctx.lineTo(b.r * 0.5 * sx, -b.r * 0.55 * sy);
      ctx.lineTo(b.r * 0.78 * sx, -b.r * 0.05 * sy);
      ctx.lineTo(b.r * 0.55 * sx, b.r * 0.55 * sy);
      ctx.lineTo(0, b.r * 0.85 * sy);
      ctx.lineTo(-b.r * 0.55 * sx, b.r * 0.55 * sy);
      ctx.lineTo(-b.r * 0.78 * sx, -b.r * 0.05 * sy);
      ctx.lineTo(-b.r * 0.5 * sx, -b.r * 0.55 * sy);
      ctx.closePath();
    };

    ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#a5122f';
    oct(1, 1); ctx.fill();
    ctx.strokeStyle = b.flash > 0 ? '#ffffff' : 'rgba(255,150,175,0.95)';
    ctx.lineWidth = 2.2; ctx.stroke();

    ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#d61f45';
    oct(0.7, 0.68); ctx.fill();
    ctx.strokeStyle = 'rgba(255,205,215,0.7)';
    ctx.lineWidth = 1.2; ctx.stroke();

    for (let s = 0; s < 2; s++) {
      const sx = s === 0 ? -1 : 1;
      ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#7d0a22';
      ctx.beginPath();
      ctx.moveTo(sx * b.r * 0.6, b.r * 0.18);
      ctx.lineTo(sx * b.r * 1.02, b.r * 0.05);
      ctx.lineTo(sx * b.r * 1.02, b.r * 0.34);
      ctx.lineTo(sx * b.r * 0.6, b.r * 0.52);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,150,175,0.8)';
      ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#ffd47b';
      ctx.fillRect(sx * b.r * 0.92 - 2, b.r * 0.18, 4, b.r * 0.08);
    }

    ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#24060f';
    ctx.beginPath(); ctx.arc(0, -b.r * 0.02, b.r * 0.38, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,170,190,0.8)';
    ctx.lineWidth = 1.5; ctx.stroke();

    const pulse = 0.6 + Math.sin(b.t * 5) * 0.4;
    ctx.fillStyle = b.flash > 0 ? '#ffffff' : '#ffe26b';
    ctx.globalAlpha = 0.55 + pulse * 0.45;
    ctx.beginPath(); ctx.arc(0, -b.r * 0.02, b.r * 0.17, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  let nebula = null;
  function buildNebula() {
    nebula = document.createElement('canvas');
    nebula.width = VW; nebula.height = VH * 2;
    const g = nebula.getContext('2d');
    g.fillStyle = '#070b1c';
    g.fillRect(0, 0, VW, VH * 2);
    const blobs = [
      { x: VW * 0.22, y: VH * 0.36, r: VW * 0.9, c: 'rgba(52,86,190,0.34)' },
      { x: VW * 0.82, y: VH * 0.86, r: VW * 0.8, c: 'rgba(126,62,190,0.26)' },
      { x: VW * 0.5, y: VH * 1.5, r: VW * 0.95, c: 'rgba(30,120,170,0.24)' }
    ];
    for (let i = 0; i < blobs.length; i++) {
      const b = blobs[i];
      const rg = g.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
      rg.addColorStop(0, b.c);
      rg.addColorStop(1, 'rgba(7,11,28,0)');
      g.fillStyle = rg;
      g.beginPath(); g.arc(b.x, b.y, b.r, 0, Math.PI * 2); g.fill();
    }
    for (let i = 0; i < 240; i++) {
      g.fillStyle = 'rgba(190,230,255,' + (0.03 + Math.random() * 0.1) + ')';
      const s = 0.6 + Math.random() * 1.8;
      g.fillRect(Math.random() * VW, Math.random() * VH * 2, s, s);
    }
  }

  function render() {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = '#050812';
    ctx.fillRect(0, 0, cw, ch);

    ctx.save();
    ctx.translate(ox, oy);
    ctx.scale(scale, scale);
    ctx.beginPath();
    ctx.rect(0, 0, VW, VH);
    ctx.clip();

    let shx = 0, shy = 0;
    if (world.shakeT > 0 && world.shakeMag > 0) {
      shx = (Math.random() - 0.5) * world.shakeMag * 2;
      shy = (Math.random() - 0.5) * world.shakeMag * 2;
    }
    ctx.translate(shx, shy);

    if (!nebula) buildNebula();
    const off = ((world.tick / 60) * 26) % (VH * 2);
    ctx.drawImage(nebula, 0, off - VH * 2, VW, VH * 2);
    ctx.drawImage(nebula, 0, off, VW, VH * 2);

    const st = world.stars;
    for (let i = 0; i < st.length; i++) {
      const s = st[i];
      let y = s.y;
      if (state === 'play') { s.y += s.v * STEP; if (s.y > VH) { s.y = -2; s.x = Math.random() * VW; } }
      ctx.globalAlpha = s.a;
      ctx.fillStyle = s.c;
      ctx.fillRect(s.x, y, s.s, s.s);
    }
    ctx.globalAlpha = 1;

    ctx.globalCompositeOperation = 'lighter';

    for (let i = 0; i < world.rings.length; i++) {
      const r = world.rings[i];
      const k = r.t / r.life;
      const rad = r.r0 + (r.r1 - r.r0) * k;
      ctx.globalAlpha = (1 - k) * 0.8;
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 2 + (1 - k) * 3;
      ctx.beginPath(); ctx.arc(r.x, r.y, rad, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.globalAlpha = 1;

    for (let i = 0; i < world.pickups.length; i++) {
      const p = world.pickups[i];
      const pulse = 0.6 + Math.sin(p.t * 7) * 0.4;
      drawGlow(p.x, p.y, 20 + pulse * 6, '#ffd47b', 0.5);
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.t * 2.4);
      ctx.fillStyle = '#ffe9b8';
      ctx.beginPath();
      ctx.moveTo(0, -9); ctx.lineTo(7, 0); ctx.lineTo(0, 9); ctx.lineTo(-7, 0);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    for (let i = 0; i < world.ebullets.length; i++) {
      const b = world.ebullets[i];
      drawGlow(b.x, b.y, b.r * 1.7, b.c, 0.6);
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.55, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = b.c;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
    }

    for (let i = 0; i < world.particles.length; i++) {
      const p = world.particles[i];
      const k = 1 - p.t / p.life;
      ctx.globalAlpha = k * 0.95;
      ctx.drawImage(glowSprite(p.color.length === 7 ? p.color : '#7be9ff', 32),
        p.x - p.size * 1.6, p.y - p.size * 1.6, p.size * 3.2, p.size * 3.2);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';

    for (let i = 0; i < world.enemies.length; i++) drawEnemyShape(world.enemies[i]);
    if (world.boss) drawBossShape(world.boss);

    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < world.bullets.length; i++) {
      const b = world.bullets[i];
      drawGlow(b.x, b.y, b.w * 1.9, b.c, 0.55);
      const tg = ctx.createLinearGradient(b.x, b.y - 16, b.x, b.y + 4);
      tg.addColorStop(0, rgba(b.c, 0));
      tg.addColorStop(1, rgba(b.c, 0.95));
      ctx.fillStyle = tg;
      ctx.fillRect(b.x - b.w * 0.28, b.y - 16, b.w * 0.56, 20);
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(b.x, b.y - 2, b.w * 0.5, b.w * 0.8, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';

    if (state === 'play' || state === 'pause') {
      for (let i = 0; i < world.players.length; i++) {
        const p = world.players[i];
        if (!p.alive) continue;
        let a = 1;
        if (p.inv > 0) a = Math.sin(p.inv * 26) > 0 ? 0.32 : 1;
        drawPlayerShape(p, a);
        if (world.players.length > 1) {
          ctx.fillStyle = p.color;
          ctx.globalAlpha = 0.85;
          ctx.font = '600 9px -apple-system, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('P' + (p.id + 1), p.x, p.y + p.r + 14);
          ctx.globalAlpha = 1;
        }
      }
    }

    if (world.hitFlash > 0) {
      ctx.fillStyle = 'rgba(255,80,120,' + (world.hitFlash * 0.42) + ')';
      ctx.fillRect(0, 0, VW, VH);
    }

    ctx.restore();
  }

  let hudTick = 0;
  function updateHud() {
    hudTick++;
    if (hudTick % 4 !== 0) return;
    const el = document.getElementById('score');
    if (el) el.textContent = String(world.score);
    const names = ['单发脉冲', '双列脉冲', '三向散射', '五向散射', '五向强化'];
    for (let i = 0; i < 2; i++) {
      const p = world.players[i];
      const box = document.getElementById(i === 0 ? 'hearts' : 'heartsP2');
      if (!box) continue;
      if (!p) { box.textContent = ''; continue; }
      let s = '';
      for (let k = 0; k < p.maxHp; k++) s += k < p.hp ? '◆' : '◇';
      box.textContent = s;
      box.style.color = p.alive ? p.color : '#6b7a90';
    }
    const p0 = world.players[0];
    const pw = document.getElementById('power');
    if (pw && p0) pw.textContent = 'P' + p0.power + ' ' + names[Math.min(4, p0.power - 1)];
    const weaponNameEl = document.getElementById('weaponName');
    if (weaponNameEl && p0) weaponNameEl.textContent = 'P1 ' + names[Math.min(4, p0.power - 1)] + (p0.alive ? '' : ' · 阵亡');
    const wn = document.getElementById('waveNum');
    if (wn) wn.textContent = String(world.wave);
    if (world.players[0]) {
      const bc = document.getElementById('bombCount');
      if (bc) bc.textContent = '×' + world.players[0].bombs;
      const bb = document.getElementById('bombCountBtn');
      if (bb) bb.textContent = '×' + world.players[0].bombs;
    }
  }

  let lastTs = 0;
  let acc = 0;

  function loop(ts) {
    if (!lastTs) lastTs = ts;
    let dt = (ts - lastTs) / 1000;
    lastTs = ts;
    if (dt > 0.1) dt = 0.1;

    if (state === 'play') {
      if (netState.connected) {
        let guard = 0;
        while (netState.queue.length && guard < 6) {
          guard++;
          const pk = netState.queue[0];
          if (world.tick >= pk.n) { netState.queue.shift(); continue; }
          world.inputs[0] = pk.inputs[0];
          world.inputs[1] = pk.inputs[1];
          while (world.tick < pk.n) {
            stepOne();
            if (world.over) break;
          }
          netState.queue.shift();
          sendInput(pk.n);
          if (pk.n % 30 === 0) {
            try {
              netState.ws.send(JSON.stringify({ t: 'hash', v: hashWorld() }));
            } catch (e) {}
          }
        }
        if (world.over) gameOver();
      } else {
        acc += dt;
        let guard = 0;
        while (acc >= STEP && guard < 8) {
          acc -= STEP;
          guard++;
          const s = sampleInput();
          world.inputs[0] = s;
          if (world.inputs.length > 1) world.inputs[1] = { dx: 0, dy: 0, b: 0 };
          stepOne();
          if (world.over) { acc = 0; break; }
        }
      }
    }

    if (banner.life > 0) {
      banner.t += dt;
      if (banner.t >= banner.life) document.getElementById('banner').classList.add('hide');
    }

    updateHud();
    render();
    requestAnimationFrame(loop);
  }

  let lastSentTick = -1;
  function sendInput(tick) {
    if (!netState.connected || !netState.ws) return;
    if (lastSentTick === tick) return;
    lastSentTick = tick;
    const s = sampleInput();
    try {
      netState.ws.send(JSON.stringify({ t: 'input', dx: s.dx, dy: s.dy, b: s.b }));
    } catch (e) {}
  }

  function bindInput() {
    cvs.addEventListener('pointerdown', function (ev) {
      if (state !== 'play') return;
      input.pointerId = ev.pointerId;
      input.lastX = ev.clientX;
      input.lastY = ev.clientY;
      try { cvs.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    cvs.addEventListener('pointermove', function (ev) {
      if (state !== 'play' || ev.pointerId !== input.pointerId) return;
      const gx = (ev.clientX - input.lastX) / scale * 1.25;
      const gy = (ev.clientY - input.lastY) / scale * 1.25;
      input.poolX += gx;
      input.poolY += gy;
      input.lastX = ev.clientX;
      input.lastY = ev.clientY;
    });
    function endDrag(ev) {
      if (ev.pointerId !== input.pointerId) return;
      input.pointerId = null;
      try { cvs.releasePointerCapture(ev.pointerId); } catch (e) {}
    }
    cvs.addEventListener('pointerup', endDrag);
    cvs.addEventListener('pointercancel', endDrag);

    window.addEventListener('keydown', function (ev) {
      const k = ev.key.toLowerCase();
      input.keys[k] = true;
      if (k === ' ' || k === 'b') { ev.preventDefault(); input.bombAt = 1; }
      if (k === 'p' || k === 'escape') togglePause();
      if (k === 'enter' && state === 'over') backToMenu();
    });
    window.addEventListener('keyup', function (ev) { input.keys[ev.key.toLowerCase()] = false; });

    const startBtn = document.getElementById('btnStart');
    if (startBtn) startBtn.addEventListener('click', function () { startPlay('campaign', 0, 1); });
    document.getElementById('btnAgain').addEventListener('click', backToMenu);
    document.getElementById('btnPause').addEventListener('click', togglePause);
    document.getElementById('btnResume').addEventListener('click', togglePause);
    document.getElementById('btnBomb').addEventListener('click', function (ev) {
      ev.preventDefault();
      input.bombAt = 1;
    });
    document.getElementById('btnExit').addEventListener('click', backToMenu);

    document.querySelectorAll('[data-mode]').forEach(function (el) {
      el.addEventListener('click', function () {
        const mode = el.getAttribute('data-mode');
        if (mode === 'coop') {
          document.getElementById('menu').classList.add('hide');
          document.getElementById('netPanel').classList.remove('hide');
          setNetStatus('连接之前先填地址和房间号');
          return;
        }
        startPlay(mode, 0, 1);
      });
    });

    document.getElementById('btnNetBack').addEventListener('click', function () {
      document.getElementById('netPanel').classList.add('hide');
      document.getElementById('menu').classList.remove('hide');
    });

    document.getElementById('btnServe').addEventListener('click', function () {
      const addr = document.getElementById('netAddr').value.trim();
      const room = (document.getElementById('netRoom').value.trim() || 'ROOM1').toUpperCase();
      const name = document.getElementById('netName').value.trim() || '玩家';
      if (!addr) { setNetStatus('先填中继地址，例如 ws://127.0.0.1:8899'); return; }
      connectNet(addr, room, name, 0);
    });

    document.getElementById('btnJoin').addEventListener('click', function () {
      const addr = document.getElementById('netAddr').value.trim();
      const room = (document.getElementById('netRoom').value.trim() || 'ROOM1').toUpperCase();
      const name = document.getElementById('netName').value.trim() || '玩家';
      if (!addr) { setNetStatus('先填中继地址，例如 ws://127.0.0.1:8899'); return; }
      connectNet(addr, room, name, 0);
    });

    document.addEventListener('visibilitychange', function () {
      if (document.hidden && state === 'play') togglePause();
    });
  }

  window.__NEONARC = function () {
    return {
      state: state, mode: world.mode, tick: world.tick, score: world.score,
      players: world.players.map(function (p) {
        return { id: p.id, x: Math.round(p.x), y: Math.round(p.y), hp: p.hp, power: p.power, alive: p.alive, bombs: p.bombs };
      }),
      enemies: world.enemies.length, ebullets: world.ebullets.length,
      boss: world.boss ? Math.round(world.boss.hp) : 0,
      hash: hashWorld(), net: netState.connected, slot: netState.slot
    };
  };
  window.__NEONARC_START = function (mode, seed, count) { startPlay(mode, seed, count); };
  window.__NEONARC_SPAWNBOSS = function () { if (!world.boss) spawnBoss(); };
  window.__NEONARC_CONNECT = function (addr, room) { return connectNet(addr, room, '测试', 12345); };
  window.__NEONARC_BEST = function () {
    try { return parseInt(localStorage.getItem(BEST_KEY) || '0', 10) || 0; } catch (e) { return 0; }
  };

  function boot() {
    world.best = window.__NEONARC_BEST();
    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('orientationchange', function () { setTimeout(resize, 150); });
    bindInput();
    document.getElementById('bestInMenu').textContent = String(world.best);
    requestAnimationFrame(loop);
  }

  boot();
})();
