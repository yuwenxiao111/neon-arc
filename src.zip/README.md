# 星际弹幕 · Neon Arc

竖屏太空弹幕射击。四种模式 + 双人联机。游戏逻辑是固定步长（1/60 秒）确定性模拟，同一套代码用于 Windows 与 iOS，联机时两端跑出的世界完全一致。

## 四种模式

| 模式 | 玩法 |
| --- | --- |
| 战役 | 波次推进，每 50 秒一个 BOSS，清完继续 |
| 无尽 | 出怪越来越快，没有终点，比谁活得久 |
| BOSS 连战 | 基本不出小怪，每 10 秒接一场首领 |
| 联机合作 | 两人同房间，各自算自己的世界，中继只转发输入 |

操作：按住屏幕拖拽飞船，或 WASD / 方向键；自动开火；右下角炸弹清屏；P / Esc 暂停。

## Windows 版

解压 `星际弹幕-win32-x64.zip`，双击 `星际弹幕.exe`。F11 全屏，Esc 退出全屏。

## iOS 版（云端 macOS 编译）

Windows 编译不出 ipa，走 GitHub Actions 的 macOS 机器：

1. GitHub 新建仓库（私有即可），把源码包整个文件夹上传，`.github` 目录要一起进去。
2. 仓库 **Actions** → 选 `build-ios-ipa` → **Run workflow**。
3. 5–10 分钟后在该次运行页面的 **Artifacts** 下载 `StarArc-unsigned-ipa`，解压得 `StarArc.ipa`。
4. 用 **Sideloadly**（Windows 版）以你的 Apple ID 重签后装到 iPhone。免费账号 7 天失效需重签。

## 联机（自建中继）

中继只做一件事：把两名玩家的输入按 tick 广播出去。不做任何游戏模拟，1 核 256MB 的机器足够带几十个房间。

在服务器上：

```
npm install ws
PORT=8899 node server/relay.js
```

放行 8899（或映射到你的 NAT 外部端口）。两端进入「联机合作」，地址填：

```
ws://你的公网IP:8899
```

房间号双方填一样的，两人都进来后自动开局。建议先在本机验证：

```
node server/relay.js
```

然后两个客户端都填 `ws://127.0.0.1:8899`、房间号 `ROOM1`。

## 同步机制

- 世界坐标固定 375×667，渲染按屏幕等比缩放，不同设备同一份世界
- 随机数全部来自共享种子的确定性流
- 服务器按 30Hz 下发 `tick` 与输入帧，客户端按顺序推进，不跳帧
- 每 30 tick 上报一次状态哈希，两端不一致服务器会广播告警

## 目录

```
app/                     游戏本体（index.html + game.js，双端共用）
shell/main.js            Electron 主进程
server/relay.js          WebSocket 中继（只转发输入）
ios/                     Swift + WKWebView 壳（XcodeGen 描述）
.github/workflows/       macOS 云端编译 ipa
```
