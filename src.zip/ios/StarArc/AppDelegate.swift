import UIKit
import WebKit
import AVFoundation

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true, options: [])
        } catch {
            print("audio session: \(error)")
        }
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = GameViewController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        try? AVAudioSession.sharedInstance().setActive(true, options: [])
    }

    func application(_ application: UIApplication,
                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return .portrait
    }
}

final class GameViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {

    private var webView: WKWebView!

    override var prefersStatusBarHidden: Bool { return true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { return .all }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.03, green: 0.04, blue: 0.11, alpha: 1)

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.suppressesIncrementalRendering = false
        config.preferences.javaScriptEnabled = true
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.preferences.setValue(true, forKey: "allowUniversalAccessFromFileURLs")

        let unlock = """
        (function () {
          var instances = [];
          function track(ctx) {
            if (!ctx) return;
            instances.push(ctx);
            try {
              if (ctx.addEventListener) {
                ctx.addEventListener('statechange', function () {
                  if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
                });
              }
            } catch (e) {}
          }
          var AC = window.AudioContext || window.webkitAudioContext;
          if (AC) {
            function Patched() {
              var ctx = new AC();
              track(ctx);
              try { if (ctx.state === 'suspended') ctx.resume(); } catch (e) {}
              return ctx;
            }
            Patched.prototype = AC.prototype;
            window.AudioContext = Patched;
            window.webkitAudioContext = Patched;
          }
          function unlock() {
            for (var i = 0; i < instances.length; i++) {
              var c = instances[i];
              try { if (c.state === 'suspended') c.resume(); } catch (e) {}
            }
          }
          window.__unlockAudio = unlock;
          var evs = ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'keydown'];
          evs.forEach(function (ev) {
            window.addEventListener(ev, unlock, { capture: true, passive: true });
          });
          var booted = false;
          function boot() {
            if (booted) return; booted = true;
            try {
              var a = document.createElement('audio');
              a.preload = 'auto'; a.loop = true; a.muted = true;
              a.setAttribute('x-webkit-airplay', 'deny');
              var p = a.play();
              if (p && p.catch) p.catch(function () {});
            } catch (e) {}
          }
          ['touchstart', 'pointerdown', 'mousedown', 'click'].forEach(function (ev) {
            window.addEventListener(ev, boot, { capture: true, passive: true });
          });
        })();
        """
        config.userContentController.addUserScript(WKUserScript(source: unlock, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        if #available(iOS 16.4, *) {
            webView.isInspectable = false
        }
        view.addSubview(webView)

        guard let dir = Bundle.main.url(forResource: "h5", withExtension: nil) else {
            return
        }
        webView.loadFileURL(dir.appendingPathComponent("index.html"),
                            allowingReadAccessTo: dir)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setNeedsUpdateOfScreenEdgesDeferringSystemGestures()
        setNeedsUpdateOfHomeIndicatorAutoHidden()
    }

    override var prefersHomeIndicatorAutoHidden: Bool { return true }

    @available(iOS 11.0, *)
    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
    }
}
